---
layout: default
title: My Classroom Diary
date: 2025-05-16
---

<p>What I love the most in teaching is how it's a two-way street. I learn as I teach...</p>
